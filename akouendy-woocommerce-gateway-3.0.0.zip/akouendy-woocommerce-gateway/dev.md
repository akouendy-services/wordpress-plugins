https://hotexamples.com/fr/site/file?hash=0xb4d1f896352b9d7ec8da7432bc3533c26d12ab2cad2d1b484d92ec74278ba6e0&fullName=plugins/woocommerce-gateway-elavon/class-wc-gateway-elavon-vm.php&project=adrianjonmiller/vadsupplies

# Remove checkout fields for dev purpose

add_filter( 'woocommerce_checkout_fields' , 'akouendy_remove_checkout_fields' ); 

function akouendy_remove_checkout_fields( $fields ) { 
    unset($fields['billing']['billing_first_name']);
    unset($fields['billing']['billing_last_name']);
    unset($fields['billing']['billing_company']);
    unset($fields['billing']['billing_address_1']);
    unset($fields['billing']['billing_address_2']);
    unset($fields['billing']['billing_city']);
    unset($fields['billing']['billing_postcode']);
    unset($fields['billing']['billing_country']);
    unset($fields['billing']['billing_state']);
    unset($fields['billing']['billing_phone']);
    unset($fields['order']['order_comments']);
    unset($fields['billing']['billing_email']);
    unset($fields['account']['account_username']);
    unset($fields['account']['account_password']);
    unset($fields['account']['account_password-2']);

    return $fields; 

}

# Dev plugins:

WP Debugging

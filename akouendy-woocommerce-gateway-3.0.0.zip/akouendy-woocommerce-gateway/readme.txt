=== Woocommerce Akouendy  Gateway ===
Contributors: akouendydev
Tags: orange money, woocommerce, payment gateway, senegal, sénégal, wave, sierra leone
Requires at least: 5.7
Tested up to: 6.3
Requires PHP: 7.0
Stable tag: 6.8.0
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html



The plugins is Senegal Mobile Money gateway for Woocommerce.

== Description ==

The plugins is Senegal Mobile Money gateway for Woocommerce.
The plugins documentation is  [here](https://docs.akouendy.com/docs/wordpress/paiement-avec-orange-money/)
Akouendy  Gateway is available for Store Owners and Merchants in:
* Senegal

== Installation ==

* 	Login to your WordPress Admin area
* 	Go to "Plugins > Add New" from the left hand menu
* 	In the search box type "Woocommerce Akouendy  Gateway"
*	From the search result you will see "Woocommerce Akouendy  Gateway Plugin" click on "Install Now" to install the plugin
*	A popup window will ask you to confirm your wish to install the Plugin.
= Configure the plugin =
To configure the plugin, go to __WooCommerce > Settings__ from the left hand menu, then click "Payment Gateways" from the top tab. You should see __"Orange Money Sénégal"__ . Click on it to configure the payment gateway.

== Screenshots ==


== Changelog ==

= 2.0.0 - 2023-02-13 =
* Add - Wave Senegal.

= 2.0.0 - 2022-10-30 =
* Add - Orange Money Senegal api.
* Tweak - Prepare the plugin to hold future payment method.
* Fix - Upgrade from old backend.